with open("input_file.txt") as input_file:
    print(input_file.read())