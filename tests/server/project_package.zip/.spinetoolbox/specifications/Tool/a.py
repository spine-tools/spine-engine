import sys

print("Hello!")
print(f"sys.platform:{sys.platform}")
