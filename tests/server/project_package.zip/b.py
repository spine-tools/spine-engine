import os
import pathlib

print(f"This file is:\n{pathlib.Path(__file__)}")
